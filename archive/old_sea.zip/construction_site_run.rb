@construction_site_ok_button = [[977, 644, '#0079F8'], [1115, 708, '#0062C9']]

@store_overload = false
@store_full_form = [[792, 342, '#E90046'], [1158, 400, '#E90046']]
@store_full_ok_button = [[908, 642, '#0079F8'], [1049, 710, '#0079F8']]

def construction_site_decider
  # dputs 'Если ему доступен construction_site'
  if @big_ship
    dputs 'Construction_site доступен'
  else
    dputs 'Construction_site не доступен'
    return false
  end

  if @store_overload
    dputs 'Склад переполнен'
    return false
  else
    return true
  end
end

def construction_site_run
  dputs 'кликнули на construction_site'
  sleep_move_and_click(@construction_site)

  @store_overload = !check_area_colors(@construction_site_ok_button, true, true)
  if !@store_overload
    dputs 'если склад не переполнен - везем'
    sleep_move_and_click(@construction_site_ok_button)
    return true
  else
    raise_unless_area(@store_full_form, 'везти нельзя только при переполненом складе проверим что это та форма')
    dputs 'закрыли форму переполненного склада'
    sleep_move_and_click(@store_full_ok_button)
  end
  false
end
