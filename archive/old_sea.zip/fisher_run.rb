@port_checker = [[0, 0, '#0'], [0, 0, '#0']]
@fisher_points = [[0, 0, '#0'], [0, 0, '#0'], [0, 0, '#0'], [0, 0, '#0'], [0, 0, '#0']]
@from_port_button = [[0, 0, '#0'], [0, 0, '#0']]

def fisher_run
  dputs 'кликнули на вход в порт'
  sleep_move_and_click(@port_button)

  dputs 'проверили расположение порта'
  if check_area_colors(@port_checker)
    dputs 'прокликали рыбу'
    @fisher_points.each do |fisher_point|
      sleep_move_and_click(fisher_point)
    end
  else
    dputs 'порт расположен НЕВЕРНО'
  end

  dputs 'кликнули на выход из порта'
  sleep_move_and_click(@from_port_button)
end
