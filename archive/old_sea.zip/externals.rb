@dy = 0 # 27
@dx = 0

def getmouselocation
  `xdotool getmouselocation`.split(' ')[0..1].map { |s| s.split(':')[1].to_i }
end

def get_color(point)
  draise 'no point' if !point || point[0].to_i.zero? || point[1].to_i.zero?

  # медленно работает, грузит видеосистему
  pixel_command = "/usr/bin/import -silent -window root -crop 1x1+#{point[0].to_i - @dx}+#{point[1].to_i - @dy} -depth 8 txt:-"
  # dputs pixel_command
  `#{pixel_command}`.split(' ')[-2]
end

def xdomove(point)
  `xdotool mousemove #{point[0] + @dx} #{point[1] + @dy} `
end

def mouse_click
  `xdotool click 1`
end

def draise(msg)
  dputs('-'*10)
  dputs(msg)
  dputs('-'*10)
  @log_file.close
  raise msg
end

def dputs(msg)
  # Думаю логи писать вместо консоли
  puts msg
  @log_file.write(msg + "\n")
end
